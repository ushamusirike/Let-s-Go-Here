﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Services.Maps;
using Windows.Storage.Streams;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Maps;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using NearMe.Helperclasses;
using Newtonsoft.Json;
using Windows.Phone.UI.Input;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace NearMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MapPoint : Page
    {
        Geolocator gl = new Geolocator();
        Geoposition gp;
        MapIcon mapicon = new MapIcon();
        DispatcherTimer timer = new DispatcherTimer();
        double zoo = 1;
        Response rs = new Response();
        List<placeslist> placelist = new List<placeslist>();
        public MapPoint()
        {
            this.InitializeComponent();
            HardwareButtons.BackPressed += HardwareButtons_BackPressed;
        }

        void HardwareButtons_BackPressed(object sender, BackPressedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame != null && rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
                e.Handled = true;
            }

        }
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            try
            {


              //  map.Visibility = Visibility.Collapsed;
                App.searchteram = (string)e.Parameter;
                //timer.Tick += timer_Tick;
                //timer.Interval = new TimeSpan(2300);
                //timer.Start();
                //gp = await gl.GetGeopositionAsync();
                //map.Center = gp.Coordinate.Point;
                ////// mapicon.Image = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///images/mapicon1.png",UriKind.RelativeOrAbsolute));

                //mapicon.Location = gp.Coordinate.Point;
                //mapicon.Title = "current Location";

                //map.MapElements.Add(mapicon);
                gp = await gl.GetGeopositionAsync();
                map.Center = gp.Coordinate.Point;
                map.ZoomLevel = 10;

                //MapIcon mapicon = new MapIcon();
                //mapicon.Location = gp.Coordinate.Point;
                //mapicon.Title = "current Location";

                //map.MapElements.Add(mapicon);
                double lat = Convert.ToDouble(gp.Coordinate.Point.Position.Latitude);
                double lon = Convert.ToDouble(gp.Coordinate.Point.Position.Longitude);

                Uri url = new Uri("https://api.foursquare.com/v2/venues/search?ll=" + lat + "," + lon + "&query=" + App.searchteram + "&oauth_token=WSZV2VE2S4JWKTNSIGTJM0KJSK3HGDTR3IPGT2XWXQVKT2S0&v=20150519");


                var client = new HttpClient();
                string content1 = await client.GetStringAsync(url);

                Rootobject rootObj = JsonConvert.DeserializeObject<Rootobject>(content1);


                if (rootObj.response == null)
                {
                    var m1 = new MessageDialog("No response.. Please Try again").ShowAsync();
                }
                else
                {
                    rs = rootObj.response;

                    if (rs.venues == null)
                    {
                        var m1 = new MessageDialog("No venues for fuel  found .. Please Try again").ShowAsync();
                    }
                    else
                    {
                        foreach (Venue v in rs.venues)
                        {
                            MapIcon mapiconA = new MapIcon();

                            BasicGeoposition ag = new BasicGeoposition();
                            ag.Latitude = v.location.lat;
                            ag.Longitude = v.location.lng;
                            Geopoint point = new Geopoint(ag);
                            mapiconA.Location = point;
                            //   mapiconA.Image = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/Map-Marker-Marker-Outside-Azure.png"));
                            mapiconA.Title = v.name;
                            
                            map.MapElements.Add(mapiconA);
                            placeslist p = new placeslist();
                            p.Name = v.name;
                            //if(v.location.address.Length>0)
                            //{
                            //    p.address = v.location.address;
                            //}
                            //if (v.location.city.Length > 0)
                            //{
                            //     p.address+=","+ v.location.city;
                            //}
                            //if (v.location.country.Length > 0)
                            //{
                            //    p.address += "," + v.location.country;
                            //}
                            p.address = v.location.address + "  " + v.location.city + "  " + v.location.country;
                            p.dist =(Convert.ToDecimal(v.location.distance)/1000)+" KM";
                            placelist.Add(p);



                        }

                        placesdetails.DataContext = placelist;
                        placesdetails.ItemsSource = placelist;
                    }
                }

                progress.Visibility = Visibility.Collapsed;
                map.Visibility = Visibility.Visible;
            }
            catch(Exception ex)
            {
                string s = ex.Message;
            }
        }

        void timer_Tick(object sender, object e)
        {

            map.ZoomLevel = zoo++;


            if (zoo == 17)
            {
                timer.Stop();
                zoo = 1;
            }
        }

        private void zoomin_Click(object sender, RoutedEventArgs e)
        {
            double level = map.ZoomLevel;
            if (level < 17)
            {
                map.ZoomLevel = level + 1;
            }


            mapicon.Location = gp.Coordinate.Point;



        }

        private void zoomout_Click(object sender, RoutedEventArgs e)
        {
            double level = map.ZoomLevel;
            if (level >= 1)
            {
                map.ZoomLevel = level - 1;
            }

            mapicon.Location = gp.Coordinate.Point;
        }

        private async void map_MapTapped(MapControl sender, MapInputEventArgs args)
        {
            Geopoint pointToReverseGeocode = new Geopoint(args.Location.Position);

            // Reverse geocode the specified geographic location.  
            MapLocationFinderResult result =
                await MapLocationFinder.FindLocationsAtAsync(pointToReverseGeocode);

            var resultText = new StringBuilder();

            if (result.Status == MapLocationFinderStatus.Success)
            {
                if (result.Locations[0].Address.District.Length > 0)
                {
                    App.maplocation = result.Locations[0].Address.District + ", " + result.Locations[0].Address.Town + ", " + result.Locations[0].Address.Country;
                    this.Frame.Navigate(typeof(msgcreated));
                }
                else
                {
                    MessageDialog dia = new MessageDialog("Select a Correct One");
                    dia.ShowAsync();
                }
                //resultText.AppendLine(result.Locations[0].Address.District + ", " + result.Locations[0].Address.Town + ", " + result.Locations[0].Address.Country);
            }

        }
        void loadplaces()
        {

        }

        private void placesdetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            placeslist p = (placeslist)placesdetails.SelectedItem;
            App.maplocation = p.Name;
            App.addtess = p.address;
            this.Frame.Navigate(typeof(msgcreated));
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(categories));
        }
    }
}
