﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using NearMe.Helperclasses;
using Windows.ApplicationModel.Contacts;
using Windows.Phone.UI.Input;
using Windows.UI.Popups;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace NearMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class contacts : Page
    {
        public contacts()
        {
            this.InitializeComponent();
            HardwareButtons.BackPressed += HardwareButtons_BackPressed;

        }


        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            progress.Visibility = Visibility.Visible;
            var contactstore = await ContactManager.RequestStoreAsync();
            IReadOnlyList<Windows.ApplicationModel.Contacts.Contact> cont = await contactstore.FindContactsAsync();
            List<helpclass> contactslist = new List<helpclass>();
            int i = 1;
            try
            {
                for (int j = 0; j < cont.Count; j++)  //foreach (Contact contac in cont)
                {
                    ContactPhone c = new ContactPhone();
                    helpclass h = new helpclass();
                    h.Name = cont[j].FirstName + cont[j].MiddleName + cont[j].LastName;
                    IList<ContactPhone> num = cont[j].Phones;
                    if (num.Count > 0 && h.Name.Length > 0)
                    {
                        h.Number = num[0].Number;
                        contactslist.Add(h);
                    }


                }
                contact.DataContext = contactslist;
                contact.ItemsSource = contactslist;
            }
            catch (Exception me)
            {
                MessageDialog dia = new MessageDialog("Something went wrong...Please reopen");
                dia.ShowAsync();
            }
            finally
            {
                progress.Visibility = Visibility.Collapsed;
            }
        }

       

        private void contact_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            helpclass selectedcont = (helpclass)contact.SelectedItem;
            App.name = selectedcont.Name;
            App.number = selectedcont.Number;
            Frame.Navigate(typeof(categories));
        }


        void HardwareButtons_BackPressed(object sender, BackPressedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame != null && rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
                e.Handled = true;
            }

        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }
    }
}
