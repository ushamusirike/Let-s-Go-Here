﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Phone.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace NearMe
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class categories : Page
    {
        public categories()
        {
            this.InitializeComponent();
            HardwareButtons.BackPressed += HardwareButtons_BackPressed;
        }
        void HardwareButtons_BackPressed(object sender, BackPressedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame != null && rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
                e.Handled = true;
            }

        }

       
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            switch(btn.Tag.ToString())
            {
                case "resturant":
                    this.Frame.Navigate(typeof(MapPoint), "Resturant");
                    break;
                case "petrol":
                    this.Frame.Navigate(typeof(MapPoint), "Petrol");
                    break;
                case "atm":
                    this.Frame.Navigate(typeof(MapPoint), "atm");
                    break;
                case "bakery":
                    this.Frame.Navigate(typeof(MapPoint), "bakery");
                    break;
                case "bank":
                    this.Frame.Navigate(typeof(MapPoint), "bank");
                    break;
                case "bus":
                    this.Frame.Navigate(typeof(MapPoint), "bus");
                    break;
                case "hotel":
                    this.Frame.Navigate(typeof(MapPoint), "hotel");
                    break;
                case "coffee":
                    this.Frame.Navigate(typeof(MapPoint), "coffee");
                    break;
                case "shopping":
                    this.Frame.Navigate(typeof(MapPoint), "shopping");
                    break;
                case "movie":
                    this.Frame.Navigate(typeof(MapPoint), "movie");
                    break;
                case "pub":
                    this.Frame.Navigate(typeof(MapPoint), "pub");
                    break;
                case "books":
                    this.Frame.Navigate(typeof(MapPoint), "books");
                    break;
            }
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(contacts));
        }
    }
}
